2 Pass Assembler
C300 - Dr. Xukai Zou

Group:
Ethan Fetsko
Sarah Rozow
Chandler Henson

----------------

Compile instructions:

- First ensure that all desired assembly files are in the "assemblyCode" folder.

- Open up Assembler.java and change the "fileName" global variable to be the 
  file name extension of the file you would like to assemble.

- Run Main.java

- The resulting object code will be found in objectCode.txt, which resides in the outmost "Assembler"
  folder.
