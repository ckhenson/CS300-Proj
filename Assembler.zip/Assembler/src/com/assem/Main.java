package com.assem;

public class Main {

    public static void main(String[] args) {

        Assembler r = new Assembler();
        r.passOne();

    }
}
